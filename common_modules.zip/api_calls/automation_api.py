from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
from utilities.utility import Utilities

logger = get_base_logger()


class AutomationApi(BaseApi):
    '''Class for Workiva Automation fuctionalities'''

    def __init__(self) -> None:
        super().__init__()

    def get_automations_list(self, resource_id: str) -> dict:
        """
        Get list of automations associated with the given spreadsheet id.

        Args:
            ss_id (str): Spreadsheet ID

        Returns:
            response(dict): JSON response contaning automation details.
        """
        logger.info("Function get_automations_list started..")

        self.headers.update({"Content-Type": "application/json"})

        url = WorkivaApiURLs.AUTOMATIONS_URL.value

        payload = {"resourceId": f"{resource_id}"}
        response = self.get_request(url=url, params=payload)
        response = Utilities.convert_to_json(response.text)
        self.headers.pop("Content-Type")

        logger.info("Function get_automations_list completed..")

        return response
    

    def delete_automation(self, automation_id: str) -> dict:
        """
        Delete an automation associated with the given spreadsheet id.

        Args:
            automation_id (str): Automation ID

        Returns:
            response(dict): JSON response confirming deletion.
        """
        logger.info("Function delete_automation started..")

        self.headers.update({"Content-Type": "application/json"})

        url = f"{WorkivaApiURLs.AUTOMATIONS_URL.value}/{automation_id}"

        response = self.delete_request(url=url)
        response = Utilities.convert_to_json(response.text)
        self.headers.pop("Content-Type")

        logger.info("Function delete_automation completed..")

        return response
