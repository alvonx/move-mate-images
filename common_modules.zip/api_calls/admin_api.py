from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
from utilities.utility import Utilities

logger = get_base_logger()


class AdminApi(BaseApi):
    '''Class for Workiva Admin fuctionalities'''

    def __init__(self) -> None:
        super().__init__()

    def get_automations_list(self, resourceId: str) -> dict:
        """
        Get list of automations associated with the given spreadsheet id.

        Args:
            ss_id (str): Spreadsheet ID

        Returns:
            response(dict): JSON response contaning automation details.
        """
        logger.info("Function get_automations_list started..")

        self.headers.update({"Content-Type": "application/json"})

        url = WorkivaApiURLs.AUTOMATIONS_URL.value

        payload = {"resourceId": f"{resourceId}"}
        response = self.get_request(url=url, params=payload)
        response = Utilities.convert_to_json(response.text)
        self.headers.pop("Content-Type")

        logger.info("Function get_automations_list completed..")

        return response

    def get_group_list(self, org_id: str, workspace_id: str) -> dict:
        """
        Get list of groups.

        Args:
            org_id (str): organization ID.
            workspace_id(str): workspace ID

        Returns:
            response(dict): JSON response contaning group details.
        """
        logger.info("Function get_group_list started..")

        url = f"{WorkivaApiURLs.ADMIN_API_URL.value}{org_id}/workspaces/{workspace_id}/groups"
        r = self.get_request(url)
        response = Utilities.convert_to_json(r.text)

        logger.info("Function get_group_list completed..")

        return response["data"]

    def get_group_users(self, org_id: str, workspace_id: str, group_id: str) -> dict:
        """
        Get list of users in the given group.

        Args:
            org_id (str): organization id.
            workspace_id(str): workspace id.
            group_id(str): id of the group whose member list is required

        Returns:
            response(dict): JSON response contaning group members' details.
        """
        logger.info("Function get_group_users started..")

        url = f"{WorkivaApiURLs.ADMIN_API_URL.value}{org_id}/workspaces/{workspace_id}/groups/{group_id}/members"
        r = self.get_request(url)
        response = Utilities.convert_to_json(r.text)

        logger.info("Function get_group_users completed..")

        return response["data"]

    def get_member_details(self, org_id: str, member_id: str) -> dict:
        """
        Get details of the specific member.

        Args:
            org_id (str): organization id.
            member_id(str): id of the member whose details are required.

        Returns:
            response(dict): JSON response contaning members' details.
        """
        logger.info("Function get_member_details started..")

        url = f"{WorkivaApiURLs.ADMIN_API_URL.value}{org_id}/users/{member_id}"
        r = self.get_request(url)
        response = Utilities.convert_to_json(r.text)

        logger.info("Function get_member_details completed..")

        return response

    def fetch_list_of_users(self) -> dict:
        """
        Get list of users.

        Returns:
            response(dict): JSON response contaning user list info.
        """
        logger.info('Function fetch_list_of_users started..')

        url = WorkivaApiURLs.USERS_API_URL.value
        response = self.get_request(url)

        logger.info('Function fetch_list_of_users completed..')

        return response.json()

    def get_workspace_permissions(self) -> dict:
        '''
        Fetches the permission details associated with the workspace.

        Returns:
            response(dict): list of the id of the permission and the permission name. Contains 'none', 'own', 'view' and 'edit' permissions
        '''
        logger.info('Function get_workspace_permissions started..')

        url = WorkivaApiURLs.PERMISSION_API_URL.value
        response = self.get_request(url=url, retry=1)

        logger.info('Function get_workspace_permissions completed..')

        return response.json()

    def get_document_permissions(self, document_id: str) -> dict:
        """
        Getting permissions currently associated with a particular document.
        Args:
            document_id(str): Document ID whos permissions are to be retrived
        Returns:
            response(dict): list of assigned permissions. Will contain user ID and permission values.
        """
        logger.info('Function get_document_permissions started..')

        url = f"{WorkivaApiURLs.DOC_PERMISSION_API_URL.value}{document_id}/permissions"
        response = self.get_request(url=url, retry=1)

        logger.info('Function get_document_permissions completed..')

        return response.json()

    def update_document_permissions(self, doc_id: str, resource_permission_modification: dict):
        """
        Updates the permissions of a document. If a user has an existing permission to the file and it is to be changed,
        the existing permission should be revoked while granting the new one.
        Args:
            doc_id (str): document which needs to be updated
            resource_permission_modification (str): dictionary with toAssign and toRevoke values. The user ID is passed as 'principal' and the permission obtaned from get_workspace_permissions as 'permission'
        Returns:
            response(dict): JSON Response
        """
        logger.info('Function update_document_permissions started..')

        url = f"{WorkivaApiURLs.DOC_PERMISSION_API_URL.value}{doc_id}/permissions/modification"
        response = self.post_request(url=url, body=resource_permission_modification, retry=1)

        logger.info('Function update_document_permissions completed..')

    def update_spreadsheet_permissions(self, spreadsheet_id: str, resource_permission_modification: dict):
        """
        Updates the permissions of a spreadsheet. If a user has an existing permission to the file and it is to be changed,
        the existing permission should be revoked while granting the new one.
        Args:
            spreadsheet_id(str): spreadsheet which needs to be updated
            resource_permission_modification(dict): dictionary with toAssign and toRevoke values. The user ID is passed as 'principal' and the permission obtaned from get_workspace_permissions as 'permission'
        Returns:
            response(dict): JSON response
        """
        logger.info('Function update_spreadsheet_permissions started..')

        url = f"{WorkivaApiURLs.SS_PERMISSIONS_API_URL.value}{spreadsheet_id}/permissions/modification"
        response = self.post_request(url=url, body=resource_permission_modification, retry=1)

        logger.info('Function update_spreadsheet_permissions completed..')

        return response
