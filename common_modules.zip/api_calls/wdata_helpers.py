# wdataHelpers.py
import requests
import polling2
import json

from base.base_api import BaseApi


class WDataHelpers(BaseApi):

    def __init__(self):
        super().__init__()
        self._bearer = self._token_manager.get_auth_token()

    def list_tables(self, env):
        header = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        url = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/table'
        r = requests.get(url, headers=header)
        output = r.json()
        tables_list = output['body']
        return tables_list

    def create_table(self, body, env):
        header = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        url = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/table'
        r = requests.post(url, headers=header, json=body)
        output = r.json()
        table_id = output['body']['id']
        return table_id

    def upload_file(self, table_id, data, filename, env):
        # stage the file
        header1 = {'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        url1 = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/file'
        file = {'file': (f'{filename}', f'{data}', 'text/csv')}
        pld = {'tableId': f'{table_id}'}
        r1 = requests.post(url=url1, headers=header1, files=file, data=pld)
        output1 = r1.json()
        print(output1)
        file_id = output1['body']['id']
        print(file_id)
        # import the file
        header2 = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        url2 = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/table/{table_id}/import'
        pld2 = {'fileId': f'{file_id}'}
        r2 = requests.post(url=url2, headers=header2, json=pld2)
        return r2.status_code

    def download_file(self, fileId, env):
        url = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/file/{fileId}/download'
        header = {'Accept': '*/*', 'Authorization': f'{self._bearer}'}
        r = requests.get(url, headers=header)
        return r.text

    def list_files(self, tableId, env):
        url = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/file'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        param = {'tableId': f'{tableId}'}
        r = requests.get(url, headers=header, params=param)
        return r.json()

    def delete_file(self, fileId, env):
        url = f'https://h.{env}.wdesk.com/s/wdata/prep/api/v1/file/{fileId}'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        r = requests.delete(url, headers=header)
        return r.json()

    def unimport_file(self, tableId, fileId, env):
        url = f'https://h.app.wdesk.com/s/wdata/prep/api/v1/table/{tableId}/import/{fileId}'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        r = requests.delete(url, headers=header)
        return r.json()

    def create_query(self, query_pload, environment):
        url = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/query'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}', 'Content-Type': 'application/json'}
        r = requests.post(url, headers=header, json=query_pload)
        return r.json()

    def execute_query(self, pload, environment):
        url = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/queryresult'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}', 'Content-Type': 'application/json'}
        r = requests.post(url, headers=header, json=pload)
        k = r.json()
        status = k['body']['status']
        query_result_id = k['body']['id']
        if status == 'RUNNING':
            url1 = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/queryresult/{query_result_id}'
            z = polling2.poll(lambda: json.loads(
                requests.get(url1, headers={
                    'Accept': 'application/json',
                    'Authorization': f'{self._bearer}'
                }).text)['body']['status'] == 'COMPLETE',
                              step=5,
                              poll_forever=True)
            if z == True:
                output = query_result_id
            else:
                output = 'this is so wrong'
        return output

    def query_result_download(self, queryresult_id, environment):
        url = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/queryresult/{queryresult_id}/download'
        header = {'Accept': '*/*', 'Authorization': f'{self._bearer}'}
        r = requests.get(url, headers=header)
        return r.text

    def retrieve_query_result(self, query_result_id, environment):
        url = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/queryresult/{query_result_id}'
        header = {'Accept': 'application/json', 'Authorization': f'{self._bearer}'}
        r = requests.get(url, headers=header)
        return r.json()

    def delete_query(self, query_id, environment):
        url = f'https://h.{environment}.wdesk.com/s/wdata/prep/api/v1/query/{query_id}'
        header = {'Accept': '*/*', 'Authorization': f'{self._bearer}'}
        r = requests.delete(url, headers=header)
        return r.status_code
