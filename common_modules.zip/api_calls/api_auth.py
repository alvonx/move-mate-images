import json
import logging
import requests
from requests import Response
from base.base_logger import get_base_logger
from utilities.user_config import UserConfig
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()


class ApiAuth:

    def __init__(self):
        self._user_config = UserConfig()
        self._headers: dict = {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}

    def _get_auth_token(self) -> str:
        """
        Obtain an authentication token from the API using client credentials.

        Returns:
            Access-token(str): The access token retrieved from the API.

        Raises:
            Exception: If there is an error in the request or response.
        """
        try:
            token_res: Response = requests.post(WorkivaApiURLs.AUTH_URL.value,
                                                data='client_id=' + self._user_config.get_client_id() +
                                                '&client_secret=' + self._user_config.get_client_secret() +
                                                '&grant_type=client_credentials',
                                                headers=self._headers)
            token_res.raise_for_status()    # Raise an HTTPError for bad responses

            token_response = json.loads(token_res.text)

            logger.info("Successfully obtained auth token.")

            return token_response['access_token']
        except requests.exceptions.RequestException as e:

            logger.error(f"Request failed: {e}")

            raise
        except json.JSONDecodeError as e:

            logger.error(f"JSON decoding failed: {e}")

            raise


class TokenManager(ApiAuth):

    def __init__(self):
        super().__init__()
        self._auth_token = self._get_auth_token()

    def regenerate_auth_token(self):
        '''
        Regenerating the Bearer Token from Workiva.
        '''
        self._auth_token = self._get_auth_token()

    def get_auth_token(self):
        '''
        Getting the Bearer Token for authorisation.

        Returns:
            Access token(str): The access token retrieved from Workiva.
        '''
        return str('Bearer ' + self._auth_token)
