import csv
from io import StringIO
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
import json

logger = get_base_logger()


class WDataApi(BaseApi):

    def __init__(self) -> None:
        super().__init__()

    def retrieve_query(self, query_id):
        """ Class: WDataApi
            Function: retrieve_query
            Parameters:
            - queryId: id of the query
            Returns: query details
            Return type: JSON"""
        logger.info("Function retrieve_query started")

        url = f'{WorkivaApiURLs.WDATA_API_URL.value}api/v1/query/{query_id}'

        res = self.get_request(url)
        logger.info("Function retrieve_query ended")

        return res.json()

    def get_query_results(self, query_data, query_id, parameters):
        """ Class: WDataApi
            Function: get_query_results
            Parameters:
            - Query queryData data
            - Query queryId ID
            - Query parameters dict
            Returns: results of the query run
            Return type: JSON"""
        body = {"isExplain": "False", "parameters": parameters, "queryDto": query_data['body'], "queryId": query_id}

        self.headers.update({'Content-Type': 'application/json'})
        url = f'{WorkivaApiURLs.WDATA_API_URL.value}api/v1/queryresult'

        query_result = self.post_request(url, body=body)
        self.headers.pop('Content-Type')

        return query_result

    def get_query_status(self, query_result_id):
        """ Class: WDataApi
            Function: get_query_status
            Parameters:
            - Query Result ID
            Returns: current status of query run
            Return type: String"""

        url = WorkivaApiURLs.WDATA_QUERY_RESULT_API.value + query_result_id
        res = self.get_request(url)

        return json.loads(res.text)['body']['status']

    def export_query_result(self, query_result_id):
        """ Class: WDataApi
            Function: export_query_result
            Parameters:
            - Query Result ID
            Returns: query result
            Return type: list"""
        self.headers.update({'Content-Type': 'application/json'})

        url = f"{WorkivaApiURLs.WDATA_API_URL.value}/api/v1/queryresult/{query_result_id}/download"

        res = self.get_request(url)

        with StringIO(res.text) as csvFile:
            csvReader = csv.reader(csvFile)
            values = list(csvReader)

        return values
