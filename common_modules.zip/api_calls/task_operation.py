import json
import requests
import pandas
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()


class TaskOperation(BaseApi):
    '''Class for Workiva Task Operation fuctionalities'''

    def __init__(self):
        super().__init__()

    def create_task(self,
                    loggedIn_user: pandas.DataFrame,
                    doc_id: str = '',
                    doc_sheet_id: str = '',
                    task_title: str = '',
                    task_description: str = '',
                    assignee_name_flag: bool = True):
        """
            Create a new task.

            Args:
                loggedIn_user (str): LoggedIn User Details
                doc_id (str): Document ID
                doc_sheet_id (str): Sheet ID

            Returns:
                dict: JSON response contaning task creation response.
            """
        try:
            logger.info("Function createtask started")
            if assignee_name_flag:
                task_description = f"Hey {loggedIn_user['displayName'].values[0]}!{task_description}"

            body = {
                "assignee": {
                    "id": f"{loggedIn_user['id'].values[0]}",
                    "displayName": f"{loggedIn_user['displayName'].values[0]}",
                    "email": f"{loggedIn_user['email'].values[0]}"
                },
                "description": f"{task_description}",
                "location": {
                    "file": f"{doc_id}",
                    "filesegment": f"{doc_sheet_id}"
                },
                "status": "Completed",
                "title": f"{task_title}"
            }

            # Send POST request
            response = self.post_request(WorkivaApiURLs.TASK_API_URL.value, body=body)

            # Check for HTTP errors
            response.raise_for_status()

            response = response.json()

            logger.info(f"Task created successfully !!!")
            logger.info(f"Task ID : {response['id']}")
            logger.info(f"Task Title : {response['title']}")
            logger.info("Function createtask ended")

            return response
        except ValueError as ve:
            logger.info("Function createtask ended")
            print(f"ValueError: {ve}")
        except requests.RequestException as re:
            logger.info("Function createtask ended")
            print(f"RequestException: {re}")
        except Exception as e:
            logger.info("Function createtask ended")
            print(f"An unexpected error occurred: {e}")

    def fetch_automation_name(self, ss_id, sheet_id, region):
        """
        Create a new task.

        Args:
            ss_id (str): SpreadSheet ID
            sheet_id (str): Sheet ID 
            region (str): Region in the sheet

        Returns:
            dict: JSON response contaning task creation response.
        """
        logger.info("Function fetchautomationname started")

        url = f"https://api.app.wdesk.com/spreadsheets/v1/spreadsheets/{ss_id}/sheets/{sheet_id}/data/{region}"

        try:
            self.headers.update({'Content-Type': 'application/json'})

            res = self.get_request(url)

            self.headers.pop('Content-Type')
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

        logger.info("Function fetchautomationname ended")

        return json.loads(res.text)
