from requests import Response

from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.utility import Utilities
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()
utility = Utilities()


class DocApi(BaseApi):

    def __init__(self) -> None:
        super().__init__()

    def copy_section(self, source_doc_id, sec_id, sec_name, parent_id, destination_doc_id, index=None):
        """
        To copy a section

        Args:
            source_doc_id: The Documnet ID (source)
            sec_id (str): section id (source)
            sec_name (str): section_name (destination)
            index (int): index with respect to parent (destination)
            parent_id : parent section detail (destination)
            destination_doc_id: The Documnet ID (destination)
        """
        logger.info("Function copy_section started..")
        url = WorkivaApiURLs.DOC_API_URL.value + source_doc_id + '/sections/' + sec_id + '/copy'
        body = {
            "sectionName": sec_name,
            "document": destination_doc_id,
            "sectionIndex": int(index),
            "sectionParent": parent_id
        }
        try:
            res = self.post_request(url, body=body, retry=1)
            logger.info(f"Section copied Successfully - {res.status_code}")
        except Exception as e:
            logger.error(f"Error in copying section: {e}")
        logger.info("Function copy_section completed..")

    def get_list_of_sections(self, doc_id) -> dict:
        """
        Get list of sections for a document.

        Args:
            doc_id (str): The document ID.

        Returns:
            list: List of sections.
        """
        logger.info("Function get_list_of_sections started..")
        res = {}

        try:
            url = WorkivaApiURLs.DOC_API_URL.value + doc_id + '/sections'
            response = self.get_request(url, retry=1)
            res = response.json()['data']
        except Exception as e:
            logger.error(f"Error in get_list_of_sections: {e}")
        logger.info("Function get_list_of_sections completed..")
        return res

    def delete_section(self, doc_id: str, sec_id: str):
        """
        Delete a specific section from a document.

        Args:
            doc_id (str): The document ID.
            sec_id (str): The section ID.
        """
        try:
            url: str = WorkivaApiURLs.DOC_API_URL.value + doc_id + '/sections/' + sec_id
            response: Response = self.delete_request(url)
            logger.info(f"Delete section response: {response}")
        except Exception as e:
            logger.error(f"Error in delete_section: {e}")

    def partially_update_section(self, doc_id, section_id, index) -> dict:
        """
        Update the details of a section in a document.

        Args:
            document_id (str): The document ID.
            section_id (str): The section ID.
            index (int): The index of the section.
        """
        logger.info("function partially_update_section started..")
        section_res = {}
        try:
            url = WorkivaApiURLs.DOC_API_URL.value + doc_id + "/sections/" + section_id
            response = self.put_request(url,
                                        body={
                                            "id": section_id,
                                            "index": int(index),
                                            "name": 'Non-Printing section',
                                            "nonPrinting": True
                                        },
                                        retry=1)
            logger.info(f"Section update response: {section_res}")
            section_res = response.json()

        except Exception as e:
            logger.error(f"Error in update_section_name: {e}")

        logger.info("function partially_update_section completed..")
        return section_res

    def get_document_details(self, doc_id) -> dict:
        """
        Get details of a particular section.

        Args:
            doc_id (str): The document ID.
            section_id (str): The section ID.

        Returns:
            dict: JSON response containing the section details.
        """
        logger.info("Function get_document_details started..")
        res = {}
        try:
            url = WorkivaApiURLs.DOC_API_URL.value + doc_id
            response = self.get_request(url, retry=1)
            res = response.json()
        except Exception as e:
            logger.error(f"Error in get_document_details: {e}")
        logger.info("Function get_document_details completed..")
        return res

    def create_new_section(self, doc_id: str, body: dict) -> dict:
        """
        Create a new section in a document.

        Args:
            doc_id (str): The document ID.
            body (dict): The body of the request containing section details.

        Returns:
            dict: JSON response containing the new section details.
        """
        logger.info("Function create_new_section started..")
        res = {}
        try:
            url: str = WorkivaApiURLs.DOC_API_URL.value + doc_id + '/sections'
            logger.info(f"URL is {url}")
            response: Response = self.post_request(url, body=body)
            res = response.json()
        except Exception as e:
            logger.error(f"Error in create_new_section: {e}")

        logger.info("Function create_new_section completed..")
        return res

    def get_particular_section(self, doc_id, section_id) -> dict:
        """
        Get details of a particular section.

        Args:
            doc_id (str): The document ID.
            section_id (str): The section ID.

        Returns:
            dict: JSON response containing the section details.
        """
        res = {}
        try:
            logger.info("function get_particular_section started.........")
            url = WorkivaApiURLs.DOC_API_URL.value + doc_id + '/sections/' + section_id
            response = self.get_request(url, retry=1)
            res = response.json()
        except Exception as e:
            logger.error(f"Error in get_particular_section: {e}")
        logger.info("function get_particular_section ended.........")
        return res

    def update_section_name(self, doc_id, section_id, parent, index, new_name):
        """
        Update the name of a sheet in a document.

        Args:
            document_id (str): The document ID.
            section_id (str): The section ID.
            name (str): The new name for the section.
            index (int): The index of the section.
            parent (str): The parent section ID.
        """
        section_res = {}
        try:
            logger.info("Function update_section_name started...........")
            url = WorkivaApiURLs.DOC_API_URL.value + doc_id + "/sections/" + section_id
            body = {"id": section_id, "index": index, "name": new_name, "parent": parent}
            response = self.put_request(url, body=body)
            section_res = response
            logger.info(f"Section name updated Successfully - {response.status_code}")
        except Exception as e:
            logger.error(f"Error in update_section_name: {e}")

        logger.info("Function update_section_name completed...........")
        return section_res

    def import_doc(self, files):
        """
        Import doc functionality

        Args:
            files: file content
        """
        res = {}
        try:
            logger.info("Function import_doc started...........")
            url = WorkivaApiURLs.DOC_IMPORT_URL.value

            response = self.post_request(url, body={}, file=files)
            res = response
        except Exception as e:
            logger.error(f"Error in import_doc: {e}")

        logger.info("Function import_doc completed...........")
        return res
