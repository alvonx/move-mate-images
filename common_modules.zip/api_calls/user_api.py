import json
import pandas
from base.base_api import BaseApi
from base.base_logger import get_base_logger

logger = get_base_logger()


class UserApi(BaseApi):
    '''Class for Workiva UserApi fuctionalities'''

    def __init__(self):
        super().__init__()

    def fetch_list_of_users(self):
        logger.info("Function fetchListOfUsers started")

        url = f'https://api.app.wdesk.com/platform/v1/users'
        response = self.get_request(url)
        data = pandas.DataFrame(response.json()['data'])
        logger.info("Function fetchListOfUsers ended")

        return data

    def get_automations_list(self, ss_Id):
        logger.info("Function getAutomationslist started")
        self.headers.update({'Content-Type': 'application/json'})

        url = 'https://h.app.wdesk.com/s/automations/api/v1/automations'
        payload = {'resourceId': f'wurl://sheets.v0/0:sheets_{ss_Id}/'}

        response = self.get_request(url, params=payload)
        self.headers.pop('Content-Type')

        logger.info("Function getAutomationslist ended")
        return json.loads(response.text)
