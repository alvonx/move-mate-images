from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()


class ChainApi(BaseApi):

    def __init__(self) -> None:
        super().__init__()

    def chain_history(self, environment_id, chain_id):
        """
        Gets the history of the given chain.

        Args:
            environmentId (str): environment id.
            chainId(str): chain id.

        Returns:
            dict: JSON response contaning chain history details.
        """
        logger.info("Function ChainHistory started")
        url = f'{WorkivaApiURLs.CHAIN_API_URL.value}{environment_id}/chain/{chain_id}/history'
        r = self.get_request(url)
        logger.info("Function ChainHistory ended")
        return r.json()

    def execute_chain(self, environment_id, chain_id, body={"runtimeVariables": {}}):
        """
        Executes a chain.

        Args:
            environmentId (str): env id of the chain.
            chainId(str): id of the chain.
            body(dict): runtime variables for the chain.

        """
        self.headers.update({'Content-Type': 'application/json'})
        url = f'{WorkivaApiURLs.CHAIN_API_URL.value}{environment_id}/chain/{chain_id}/start'
        r = self.post_request(url, body=body)
        self.headers.pop('Content-Type')
        return r.json()
