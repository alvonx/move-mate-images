import json
import time
import pandas
from requests import Response
import requests
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
from utilities.utility import Utilities

logger = get_base_logger()


class FileApi(BaseApi):
    '''Class for Workiva File fuctionalities'''

    def __init__(self) -> None:
        super().__init__()

    def get_list_of_files(self, container_id=None, name=None, kind=None) -> list:
        '''
        Getting list of all files and folders from Workiva
        
        :param container_id: Folder container id
        :param name: File name
        :param kind: File kind
        :return: file_list(list) 
        '''
        logger.info("Function get_list_of_files started............")
        url: str = WorkivaApiURLs.FILE_API_URL.value
        payload = Utilities.get_payload(container_id, name, kind)
        file_list = []

        try:
            response: Response = self.get_request(url=url, params=payload)
            file_list: list = response.json()['data']

            while ('@nextLink' in response.json()):
                response: Response = self.get_request(url=response.json()['@nextLink'], params=json.dumps(payload))
                file_list.extend(response.json()['data'])
        except Exception as e:
            logger.error(f"Error in get_list_of_folder: {e}")

        logger.info("Function get_list_of_files ended............")
        return file_list

    def get_parent_id(self, file_id: str) -> str:
        """
        Get the parent folder ID where the document is located.

        Args:
            file_id (str): The file ID.

        Returns:
            Response: The response object containing the parent ID.
        """
        logger.info("Function get_parent_id started...............")
        container_id = ''

        try:
            url = WorkivaApiURLs.FILE_API_URL.value + file_id
            res = self.get_request(url)

            if res.status_code == 200:
                container_id: str = json.loads(res.text)['container']

        except Exception as e:
            logger.error(f"Error in get_parent_id: {e}")

        logger.info("Function get_parent_id ended...............")
        return container_id

    def rename_file(self, doc_id: str, payload: dict):
        '''
        Rename File in Workiva
        
        :param doc_id: ID of file to rename 
        :param payload: document name to rename 
        '''
        logger.info("Function rename_file started...............")
        url: str = WorkivaApiURLs.FILE_API_URL.value + doc_id
        res = {}

        try:
            response = self.put_request(url=url, body=payload)
            res = response.status_code

        except Exception as e:
            logger.error(f"Error in rename_file: {e}")

        logger.info("Function rename_file ended...............")
        return res

    def get_file_detail(self, file_id: str):
        """
        Retrieves a file from the workspace
        :param file_id: ID of the files
        :return: file details
        """
        logger.info("Function get_file_detail started...............")
        url = WorkivaApiURLs.FILE_API_URL.value + file_id
        res = {}

        try:
            response = self.get_request(url=url)
            res = response.json()

        except Exception as e:
            logger.error(f"Error in rename_file: {e}")

        logger.info("Function get_file_detail ended...............")
        return res
    
    def create_file(self, file_name: str, kind: str, container_id: str):
        """
        Creates a file in the workspace

        :param file_name: name of the file
        :param kind: file kind
        :param container_id: container id
        :return: file details
        """
        logger.info("Function create_file started...............")
        url = WorkivaApiURLs.FILE_API_URL.value
        body = {"name": file_name, "kind": kind, "container": container_id}
        res = {}

        try:
            response = self.post_request(url=url, body=body)
            res = response.json()

        except Exception as e:
            logger.error(f"Error in create_file: {e}")

        logger.info("Function create_file ended...............")
        return res

    def move_file(self, destination_container_id: str, file_id: str, file_name: str, kind: str):
        """
        Moves a file to a specified container

        :param dest_container_id:
        :param file_id:
        :param file_name:
        :param kind: file kind
        """
        logger.info("Function move_file started...............")
        url = WorkivaApiURLs.FILE_API_URL.value + file_id
        body = {"container": destination_container_id, "kind": kind, "name": file_name}
        res = {}

        try:
            response = self.put_request(url=url, body=body)
            res = response.json()

        except Exception as e:
            logger.error(f"Error in move_file: {e}")

        logger.info("Function move_file ended...............")
        return res

    def import_file(self, file_name, kind, file_content):
        """
        Import a file

        :param file_name: file name
        :param kind: file kind
        :param file_content:
        """
        logger.info("Function import_file started...............")
        body = {"fileName": file_name, "kind": kind}
        url = WorkivaApiURLs.FILE_API_URL.value + 'import'
        res = {}

        try:
            response = self.post_request(url=url, body=body)
            response = requests.put(response.json()['uploadUrl'], data=file_content, headers=self.headers)
            res = response
        except Exception as e:
            logger.error(f"Error in import_file: {e}")

        logger.info("Function import_file ended...............")
        return res

    def export_file(self, doc_id, required_sections):
        """
        Exports a workiva file as a pdf.

        Args:
            doc_id : id of the document to be exported
            required_sections: list of doc sections that need to be exported

        Returns:
            exported_file: JSON Object containing file contents.
        """
        export_url = WorkivaApiURLs.DOC_API_URL.value + doc_id + "/export"
        try:
            body = {
                "pdfOptions": {
                    "includeLeaderDots": True,
                },
                "format": "pdf",
                "sections": required_sections,
            }

            # Posting the export request
            export_api_response = self.post_request(url=export_url, body=body)
            time.sleep(5)
            logger.info(
                f"Export API response: {export_api_response.text}, Status Code: {export_api_response.status_code}")

            # Checking the operation status
            operations_url = export_api_response.headers.get("location")
            if operations_url:
                logger.info(f"Operations URL: {operations_url}")
                operation_response = self.get_request(operations_url).json()
                time.sleep(5)
                logger.info("Checking operation status...")

                # Wait for the operation to complete
                while operation_response["status"] != "completed":
                    logger.info("Operation not completed, checking again...")
                    operation_response = self.get_request(operations_url).json()
                    time.sleep(5)
                logger.info("Operation completed.")

                # Fetching the exported file
                self.headers.pop('Accept')
                exported_file = self.get_request(operation_response["resourceUrl"])
                logger.info("Exported file fetched successfully.")
                return exported_file
            else:
                logger.info("No operations URL found in headers.")
        except Exception as e:
            logger.error(f"Error exporting file to csv/pdf : {e}")
            return None
        
    def csr_copy_file(self, file_id:str, destination_container_id:str) ->str:
        """
        Copies  file in Workiva.

        Args:
            file_id : ID of the file to be copied
            destination_container_id: Id of the container where the folder needs to be copied

        Returns:
            file_id: Id of the file created.
        """
        try:
            url = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value+"/files/"+file_id+"/copy"

            body = {
                "destinationContainer": destination_container_id,
                "options": {
                    "includeAttachments": True,
                    "includeComments": True,
                    "includeDocumentMarkup": True,
                    "includeInputCellValues": True,
                    "includeOutlineLabels": True,
                    "includeWdataIncomingConnections": True,
                    "includeWdataOutgoingConnections": True,
                    "includeXBRL": True,
                    "includeXBRLDisconnected": True,
                    "keepInputModeEnabled": True,
                    "shallowCopy": True
                }
            }
            r = self.post_request(url, body)
            
            status = ''
            while status != "completed" and status != "cancelled" and status != "failed":
                time.sleep(5)
                try:
                    res = self.get_request(url=r.headers['Location'])
                except Exception as e:
                    logger.error(f"Error in retriving copy status: {e}")
                status = res.json()['status'] 
                
            if status == "completed":
                try:
                    res = self.get_request(url=res.json()["resourceUrl"])
                except Exception as e:
                    logger.error(f"Error in retriving copy file results: {e}")  
                return res.json()

        except Exception as exception:
            logger.error(f"Error coping file: {exception}")
            raise exception

