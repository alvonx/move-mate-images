import requests
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()


class ScriptApi(BaseApi):
    '''Class for Workiva Script fuctionalities'''

    def __init__(self) -> None:
        super().__init__()

    def execute_script(self, script_id, data):
        logger.info("Function execute_script started")
        url = WorkivaApiURLs.SCRIPT_API_URL.value + script_id + "/execution"
        try:
            res = self.post_request(url=url, body=data)

        except Exception as e:
            logger.error(f"Error in execute script: {e}")

        logger.info("Function execute_script ended")
        return res

    def retrive_script_status(self, url):
        logger.info("Function retrive_script_status started")
        try:
            res = self.get_request(url=url)

        except Exception as e:
            logger.error(f"Error in retriving script status: {e}")

        logger.info("Function retrive_script_status ended")
        return res.json()['status']

    def get_sources_list(self, script_id):
        logger.info("Function get_sources_list started..")
        url = WorkivaApiURLs.SCRIPT_API_URL.value + script_id + "/sources"
        try:
            res = self.get_request(url=url)

        except Exception as e:
            logger.error(f"Error in execute script: {e}")

        logger.info("Function get_sources_list ended")
        return res.json()

    def delete_source(self, script_id, source_id):
        logger.info("Function delete_source started..")
        url = WorkivaApiURLs.SCRIPT_API_URL.value + script_id + "/sources/" + source_id
        try:
            self.delete_request(url=url)

        except Exception as e:
            logger.error(f"Error in execute script: {e}")

        logger.info("Function delete_source ended")

    def create_new_source(self, script_id: str, source_name: str, content_type: str):
        logger.info("Function create_new_source started..")

        url = WorkivaApiURLs.SCRIPT_API_URL.value + script_id + "/sources"
        try:
            body = {"path": f"{source_name}", "type": content_type}
            res = self.post_request(url=url, body=body)
        except Exception as e:
            logger.error(f"Error in execute script: {e}")
        return res.json()

    def create_zip_source(self, script_id: str, source_name: str, file_content):
        logger.info("Function create_new_source started..")

        url = 'https://app.wdesk.com/s/scripting/v1/scripts/' + script_id + "/sources"

        try:
            body = {"path": f"{source_name}"}
            res = self.post_request(url=url, body=body)
            upload_url = 'https://app.wdesk.com/s/scripting/v0/scripts/' + script_id + '/files/' + res.json()['id']
            response = requests.put(upload_url, files=file_content, headers=self.headers)
        except Exception as e:
            logger.error(f"Error in execute script: {e}")
        return res.json()

    def initiate_source_upload(self, script_id: str, source_id: str, file_content):
        logger.info("Function initiate_source_upload started..")

        url = WorkivaApiURLs.SCRIPT_API_URL.value + script_id + "/sources/" + source_id + "/contentUpload"
        try:

            response = self.post_request(url=url, body={})
            response = requests.put(response.json()['uploadUrl'], data=file_content, headers=self.headers)
            res = response
        except Exception as e:
            logger.error(f"Error in execute script: {e}")
        return res
