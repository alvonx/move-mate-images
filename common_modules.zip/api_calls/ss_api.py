import time
import requests
from requests import Response, exceptions
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.utility import Utilities
from utilities.workiva_api_urls import WorkivaApiURLs

logger = get_base_logger()


class SSApi(BaseApi):
    '''
    Class for Workiva Spreadsheet fuctionalities
    '''

    def __init__(self) -> None:
        super().__init__()

    def create_sheet(self, spreadsheet_id: str, sheet_index: int, sheet_name: str, parent_id: str) -> dict:
        """
        create sheet in a given Spreadsheet ID.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_index: The index(with respect to parent) where sheet needs to be created.
        :param sheet_name: New sheet name.
        :param parent_id: The parent ID of the new sheet.
        :return response: JSON response.
        """
        logger.info("Function create_sheet started........")

        url = WorkivaApiURLs.SS_SS_API_URL.value + spreadsheet_id + "/sheets"
        try:
            data = {"index": sheet_index, "name": sheet_name, "parent_id": parent_id}
            response = self.post_request(url=url, body=data)
            response.raise_for_status()
            logger.info(f"Successfully created sheet.")

        except exceptions.RequestException as e:
            logger.error(f"Error creating sheet : {e}")

        return Utilities.convert_to_json(response.text)

    def get_sheets(self, spreadsheet_id: str) -> dict:
        """
        Retrieve sheets under the provided spreadsheet ID.

        :param spreadsheet_id: The spreadsheet ID.
        :return response: A dictionary containing the sheet data.
        """
        logger.info("Function get_sheets started.......")

        url: str = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/sheets/"
        try:
            response = self.get_request(url)
            response.raise_for_status()
            logger.info(f"Successfully retrieved sheets.")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving sheets: {e}")

        return Utilities.convert_to_json(response.text)

    def get_raw_data(self, spreadsheet_id: str, sheet_id: str, data_range: str = ':') -> dict:
        """
        Retrieve raw data from a sheet.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param data_range(optional): The range of the data needed.
        :return response: The raw data from the sheet in JSON format.
        """
        logger.info("Function get_raw_data started........")

        url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/sheets/" + sheet_id + "/values/" + data_range
        response: Response = Response()
        try:
            response = self.get_request(url)
            response.raise_for_status()
            logger.info(f"Successfully retrieved raw data.")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving raw data: {e}")

        return Utilities.convert_to_json(response.text)

    def get_sheet_format_data(self, spreadsheet_id: str, sheet_id: str, data_range: str = '') -> dict:
        """
        Retrieve format data from a sheet.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param data_range(optional): The range of the sheet format needed.
        :return response: The sheet format data in JSON format.
        """
        logger.info("Function get_sheet_format_data started........")

        if data_range != '':
            url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + '/sheets/' + sheet_id + '/sheetdata?$cellrange=' + data_range
        else:
            url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + '/sheets/' + sheet_id + '/sheetdata'

        try:
            response = self.get_request(url=url)
            response.raise_for_status()
            logger.info(f"Successfully retrieved sheet format data.")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving sheet format data : {e}")

        return Utilities.convert_to_json(response.text)

    def update_table_name(self, spreadsheet_id: str, sheet_id: str, new_sec_name: str, table_res: dict) -> dict:
        """
        Update the name of a table.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param new_sec_name: The new section name.
        :param table_res: The response containing table data.
        :return: The response from the update request.
        """
        logger.info("Function update_table_name started.......")

        url: str = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/sheets/" + sheet_id
        try:
            for table in table_res['data']:
                if table['id'] == sheet_id:
                    table['name'] = new_sec_name
                    body = {
                        "children": table['children'],
                        "dataset": table['dataset'],
                        "id": table['id'],
                        "index": table['index'],
                        "name": new_sec_name,
                        "parent": table['parent']
                    }
                    response = self.put_request(url=url, body=body)
                    response.raise_for_status()
                    logger.info(f"Successfully updated table name.")
                    return Utilities.convert_to_json(response.text)

            logger.info(f"Sheet not found in the table response.")
            return {}

        except exceptions.RequestException as e:
            logger.error(f"Error updating table name: {e}")
            return {}

    def update_sheet_name(self, spreadsheet_id: str, sheet_id: str, new_sheet_name: str) -> dict:
        """
        Updating Sheet name for a given Sheet ID

        :param spreadsheet_id: Spread sheet ID
        :param sheet_id: Sheet ID 
        :param new_sheet_name: The new sheet name to update
        """
        logger.info("Function update_sheet_name started...........")

        url: str = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/sheets/" + sheet_id
        try:
            response = self.put_request(url, body={"index": 0, "name": new_sheet_name})
            response.raise_for_status()
            logger.info(f"Successfully updated sheet name.")

        except exceptions.RequestException as e:
            logger.error(f"Error updating sheet name: {e}")

        return Utilities.convert_to_json(response.text)

    def update_range(self, spreadsheet_id: str, sheet_id: str, data_range: str, values: list):
        """
        Update a range of values in a sheet.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param data_range: The range to update.
        :param values: The values to update in the range.
        :return: JSON response.
        """
        logger.info("Function update_range started...........")

        url: str = WorkivaApiURLs.SS_SS_API_URL.value + spreadsheet_id + "/sheets/" + sheet_id + "/data/" + data_range
        self.headers.update({"Content-Type": "application/json"})
        response: Response = Response()
        try:
            response = self.put_request(url=url, body={"values": values})
            response.raise_for_status()
            self.headers.pop("Content-Type")

            logger.info(f"Successfully updated range.")
        except exceptions.RequestException as e:
            logger.error(f"Error updating range: {e}")

        return response

    def update_sheet_content(self, spreadsheet_id, sheet_id, format_body):
        """
        Update format data in a sheet.

        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param format_body: The format body to be updated.
        :return: JSON response.
        """
        logger.info("Function update_sheet_content started........")

        url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + '/sheets/' + sheet_id + '/update'
        response: Response = Response()
        try:
            response = self.post_request(url=url, body=format_body)
            response.raise_for_status()
            time.sleep(1)
            logger.info(f"Successfully formatted sheet data")

        except exceptions.RequestException as e:
            logger.error(f"Error formatting sheet data : {e}")

        return response

    def publish_document(self, spreadsheet_id: str) -> dict:
        """
        To Publish a document

        :param spreadsheet_id: The spreadsheet ID.
        :return: JSON response.
        """
        logger.info("Function publish_document started........")

        url = WorkivaApiURLs.SS_SS_API_URL.value + spreadsheet_id + '/publish'
        response: Response = Response()
        try:
            body = {"all": True}
            response = self.post_request(url, body)
            response.raise_for_status()
            logger.info("Function publish_document ended........")

        except exceptions.RequestException as e:
            logger.error(f"Error in publishing document: {e}")

        return Utilities.convert_to_json(response.text)

    def export_sheet(self, spreadsheet_id: str, sheet_id: str, format: dict):
        """
        Export the given Workiva document as a csv.
                
        :param spreadsheet_id: The spreadsheet ID.
        :param sheet_id: The sheet ID.
        :param format: export format (csv or pdf).
        :param page_width: page width
        :return: JSON file contaning file contents to be exported.
        """
        logger.info("Function export_csv started........")

        url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/export"
        response: Response = Response()
        try:
            body = {}
            if format['documentType'] == "csv":
                body = {
                    "format": format['documentType'],
                    "sheets": [sheet_id],
                    "csvOptions": {
                        "exportAsFormulas": True
                    }
                }
            elif format['documentType'] == "pdf":
                body = {
                    "format": format['documentType'],
                    "sheets": [sheet_id],
                    "pdfOptions": {
                        "includeHyperlinks": True,
                        "pageWidth": format['pageWidth'],
                        "showGridlines": True
                    }
                }
            else:
                logger.info("Invalid export format")

            response = self.post_request(url=url, body=body)

            operations_url = response.headers.get("location")

            # export begins here
            if operations_url:
                logger.info(f"Operations URL: {operations_url}")

                time.sleep(15)

                operation_response = self.get_request(operations_url).json()

                logger.info("Checking operation status...")

                # Wait for the operation to complete
                while operation_response["status"] != "completed":

                    logger.info("Operation not completed, checking again...")

                    operation_response = requests.get(operations_url).json()

                    time.sleep(5)

                logger.info("Operation completed.")

                # Fetching the exported file
                self.headers.pop('Accept')
                exported_file = self.get_request(operation_response["resourceUrl"])
                self.headers.update({"Accept": "application/json"})

                logger.info("Exported file fetched successfully.")
                return exported_file

            else:
                logger.info("No operations URL found in headers.")
                return None

        except Exception as e:
            logger.error(f"Error exporting file to csv/pdf : {e}")
            return None

    def delete_sheet_contents(self, spreadsheet_id, sheet_id, range):
        """
        Returns sheet data as a dataframe.
                
        Args:
            spreadsheet_id : id of the spreadsheet
            sheet_id: id of the sheet
            range: cell range
            
        Returns:
            Deletes data from the specified range.
        """
        try:
            url = WorkivaApiURLs.SS_API_URL.value + spreadsheet_id + "/sheets/" + sheet_id + "/values/" + range

            body = Utilities.get_delete_sheet_contents_body(range)
            response = self.put_request(url=url, body=body)
            logger.info(f"Successfully deleted sheet contents.")

        except Exception as e:
            logger.info('Error occured: ', str(e))
