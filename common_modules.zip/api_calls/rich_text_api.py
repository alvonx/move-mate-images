import json
import time
import requests
from requests import exceptions
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
from utilities.utility import Utilities

logger = get_base_logger()


class RichTextApi(BaseApi):

    def __init__(self) -> None:
        super().__init__()


    def get_richtext_id_revision(self, doc_id: str, section_id: str) -> tuple[str, str]:
        """
        Retrieve Richtext ID from the API using the provided document ID and section ID.

        :param doc_id: The ID of the document to fetch the Richtext ID.
        :param section_id: The ID of particular section of the document to fetch the Richtext ID.
        :return: The Richtext ID of the section in the document.
        """
        logger.info("Function get_richtext_id started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'documents/' + doc_id + '/sections/' + section_id
        try:
            response = self.get_request(url=url)
            response.raise_for_status()
            richtext = Utilities.convert_to_json(response.text)
            logger.info("Successfully retrieved Richtext ID")
            return richtext['body']['richText'], richtext['body']['revision']
        
        except exceptions.RequestException as e:
            logger.error(f"Error retrieving Richtext ID: {e}")
            return ''

   
    def get_richtext_content(self, richtext_id: str) -> dict:
        """
        Retrieve Richtext content from the API using the provided Richtext ID.

        :param richtext_id: The Richtext ID of the section in the document.
        :return: The Richtext content for the given Richtext ID in JSON format.
        """
        logger.info("Function get_richtext_content started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/richText/' + richtext_id + '/paragraphs'
        try:
            response = self.get_request(url=url)
            response.raise_for_status()
            logger.info("Successfully retrieved Richtext content")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving Richtext Content: {e}")
        
        return Utilities.convert_to_json(response.text)
    
    def update_richtext_content(self, richtext_id: str, payload: dict) -> None:
        """
        Update Richtext content using the provided Richtext ID and payload.

        :param richtext_id: The Richtext ID of the section in the document.
        :param payload: The payload containing the content to be updated.
        :return: The response from the API after updating the Richtext content.
        """
        logger.info("Function update_richtext_content started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/richText/' + richtext_id + '/edit'
        try:
            response = self.post_request(url=url, body=payload)
            response.raise_for_status()
            logger.info("Successfully updated Richtext content")
        
        except exceptions.RequestException as e:
            logger.error(f"Error updating Richtext Content: {e}")
        return None