import json
import time
import requests
from requests import exceptions
from base.base_api import BaseApi
from base.base_logger import get_base_logger
from utilities.workiva_api_urls import WorkivaApiURLs
from utilities.utility import Utilities

logger = get_base_logger()


class TableApi(BaseApi):

    def __init__(self) -> None:
        super().__init__()

   
    def get_table_content(self, table_id: str) -> dict:
        """
        Retrieve Table content from the API using the provided Table ID.

        :param table_id: The Table ID of the section in the document.
        :return: The Table content for the given Table ID in JSON format.
        """
        logger.info("Function get_table_content started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/tables/' + table_id + '/cells'
        try:
            response = self.get_request(url=url)
            response.raise_for_status()
            logger.info("Successfully retrieved Table content")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving Table Content: {e}")
        
        return Utilities.convert_to_json(response.text)
    
    def get_table_properties(self, table_id: str) -> dict:
        """
        Retrieve Table properties from the API using the provided Table ID.

        :param table_id: The Table ID of the section in the document.
        :return: The Table properties for the given Table ID in JSON format.
        """
        logger.info("Function get_table_properties started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/tables/' + table_id + '/properties'
        try:
            response = self.get_request(url=url)
            response.raise_for_status()
            logger.info("Successfully retrieved Table properties")

        except exceptions.RequestException as e:
            logger.error(f"Error retrieving Table properties: {e}")
        
        return Utilities.convert_to_json(response.text)
    
    
    def update_table_content(self, table_id: str, payload: dict) -> None:
        """
        Update Table content using the provided Table ID and payload.

        :param table_id: The Table ID of the section in the document.
        :param payload: The payload containing the content to be updated.
        :return: The response from the API after updating the Table content.
        """
        logger.info("Function update_table_content started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/tables/' + table_id + '/edit'
        try:
            response = self.post_request(url=url, body=payload)
            response.raise_for_status()
            logger.info("Successfully updated Table content")
        
        except exceptions.RequestException as e:
            logger.error(f"Error updating Table Content: {e}")
        return None
    

    def update_table_properties(self, table_id: str, payload: dict) -> None:
        """
        Update Table properties using the provided Table ID and payload.

        :param table_id: The Table ID of the section in the document.
        :param payload: The payload containing the properties to be updated.
        :return: None
        """
        logger.info("Function update_table_properties started........")

        url: str = WorkivaApiURLs.PROTOTYPE_PLATFORM_URL.value + 'content/tables/' + table_id + '/properties'
        try:
            response = self.patch_request(url=url, body=payload)
            response.raise_for_status()
            logger.info("Successfully updated Table properties")

        except exceptions.RequestException as e:
            logger.error(f"Error updating Table properties: {e}")
        
        return None