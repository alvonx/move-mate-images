from typing import Union
import pandas
import logging
import json

from base.base_logger import get_base_logger

logger = get_base_logger()


class Utilities:

    @staticmethod
    def get_update_range_body(data: list):
        return {"values": data}

    @staticmethod
    def get_dataframe(data: Union[list, dict], columns=None):
        '''
        Typecasting the data in pandas DataFrame with first row as a columns

        Returns: 
            Pandas DataFrame
        '''
        if columns is None:
            columns = data[0]
            data = data[1:]
        return pandas.DataFrame(data, columns=columns)

    @staticmethod
    def get_specific_sec_id(sec_res, sec_name: str, flag: bool = True) -> str:
        for sec in sec_res:
            if not flag:
                if sec_name == sec['name'].split(' ')[1]:
                    return sec['id']

            if sec_name == sec['name']:
                return sec['id']
        return ''

    @staticmethod
    def get_specific_sheet_id(sheet_res: dict, sheet_name: str) -> str:
        """
        Get the specific sheet ID for a given sheet name.

        :param sheet_res: The response containing sheet data.
        :param sheet_name: The name of the sheet to find.
        :return: The ID of the specific sheet.
        """
        try:
            for sheet in sheet_res['data']:
                if sheet_name.strip().lower() == sheet['name'].strip().lower():

                    logger.info(f"Found sheet_id for sheet_name: {sheet_name}")

                    return sheet['id']

            logger.info(f"Sheet name {sheet_name} not found in the response.")
        except KeyError as e:
            logger.error(f"Error processing sheet response: {e}")
        return ''

    @staticmethod
    def get_section_attributes(sec_res, sec_name, param):
        logger.info(f"Finding section attribute: {param}")
        for i in sec_res:
            if sec_name.lower() in i['name'].lower():
                if param == 'parent':
                    if i['parent']:
                        data = i['parent']['id']
                    else:
                        data = None
                else:
                    data = i[f'{param}']
                logger.info(f"Found section attribute: {data}")
                return data
        return f"{param.upper()} NOT FOUND"

    @staticmethod
    def get_payload(container_id, name, kind):
        """
        Get the specific payload to get list of file

        :param container_id: Folder container id
        :param name: File name
        :param kind: File kind
        :return: payload for get_list_of_file api call
        """
        if container_id and kind:
            payload = {
                "$orderBy": "modified.dateTime desc",
                "$filter": f"container eq '{container_id}' and kind eq '{kind}'"
            }
        elif kind and name:
            payload = {"$orderBy": "modified.dateTime desc", "$filter": f"name contains '{name}' and kind eq '{kind}'"}
        elif container_id:
            payload = {"$orderBy": "modified.dateTime desc", "$filter": f"container eq '{container_id}'"}
        elif name:
            payload = {"$orderBy": "modified.dateTime desc", "$filter": f"name contains '{name}'"}
        elif kind:
            payload = {"$orderBy": "modified.dateTime desc", "$filter": f"kind eq '{kind}'"}
        else:
            payload = {"$orderBy": "modified.dateTime desc"}

        return payload

    @staticmethod
    def get_file_id(file_list: list, file_name: str) -> str:
        """
        Returns file id from file_list for file name

        :params file_list: list of files
        :params file_name: file name
        :return : file id
        """
        file_id: str = ''
        for file in file_list:
            if file_name.lower() in file['name'].lower():
                file_id = file['id']
                break

        return file_id

    @staticmethod
    def get_org_id(automations_list):
        """
        Gets the organization id.

        :param automations_list: List of automations.

        :return: The organization id.
        """
        logger.info("Function get_org_id started")
        org_id = automations_list['_embedded']['automations'][0]['executor']['_organizationId']
        logger.info("Function get_org_id ended")
        return org_id

    @staticmethod
    def get_workspace_id(automations_list):
        """
        Gets the workspace id.

        :param automations_list: List of automations.

        :return: The workspace id.
        """
        logger.info("Function get_workspace_id started")
        workspace_id = automations_list['_embedded']['automations'][0]['executor']['_workspaceId']
        logger.info("Function get_workspace_id ended")
        return workspace_id

    @staticmethod
    def convert_to_json(data):
        """
        Converts string to json.

        :param data: string data.

        :return: converted JSON data.
        """
        return json.loads(data)

    @staticmethod
    def get_hide_row_body(end_index: int, start_index: int, force=True) -> dict:
        """
        Gets hide row body.

        :param end: end row.
        :param start: start row.
        :param force(optional): force(True/False).

        :return: hide row body.
        """
        logger.info("Function get_hide_row_body started")
        hide_row_body = {"hideRows": {"force": force, "intervals": [{"end": end_index, "start": start_index}]}}
        logger.info("Function get_hide_row_body ended")
        return hide_row_body

    @staticmethod
    def get_delete_sheet_contents_body(delete_range: str) -> dict:
        """
        Gets delete sheet contents in a range body.

        :param delete_range: The range of the data to be deleted.

        :return: values body.
        """
        logger.info("Function get_delete_sheet_contents_body started")

        range_list = delete_range.split(':')
        col_max = (ord(range_list[1][0]) - ord(range_list[0][0])) + 1
        row_max = (int(range_list[1][1:]) - int(range_list[0][1:])) + 1

        row = 1
        values = []
        while row <= row_max:
            col = 1
            element = []
            while col <= col_max:
                element.append('')
                col += 1
            values.append(element)
            row += 1

        body = {'range': delete_range, 'values': values}

        logger.info("Function get_delete_sheet_contents_body ended")
        return body

    @staticmethod
    def get_delete_range_body(start_index: int, end_index=None, force=True) -> dict:
        """
        Gets delete a range of rows in a sheet body.

        :param start_index: The start index of the range to delete.
        :param end_index: The end index of the range to delete.
        :param force(optional): force(True/False).
        """
        logger.info("Function get_delete_range_body started")

        if end_index:
            body = {"deleteRows": {"force": force, "intervals": [{"start": start_index, "end": end_index}]}}
        else:
            body = {"deleteRows": {"force": force, "intervals": [{"start": start_index}]}}

        logger.info("Function get_delete_range_body ended")
        return body

    @staticmethod
    def get_hide_range_body(start_index: int, end_index=None, force=True) -> dict:
        """
        Gets Body for HideRows Range of Rows in a Sheet Body

        :param start_index: The start index of the range to hide.
        :param end_index: The end index of the range to hide.
        :param force(bool): default=True.
        """
        logger.info("Function get_hide_range_body started")

        if end_index:
            body = {"hideRows": {"force": force, "intervals": [{"start": start_index, "end": end_index}]}}
        else:
            body = {"hideRows": {"force": force, "intervals": [{"start": start_index}]}}

        logger.info("Function get_hide_range_body ended")
        return body

    @staticmethod
    def get_unhide_range_body(start_index: int, end_index=None, force=True) -> dict:
        """
        Gets Body for UnhideRows Range of Rows in a Sheet Body

        :param start_index: The start index of the range to unhide.
        :param end_index: The end index of the range to unhide.
        :param force(bool): default=True.
        """
        logger.info("Function get_unhide_range_body started")

        if end_index:
            body = {"unhideRows": {"force": force, "intervals": [{"start": start_index, "end": end_index}]}}
        else:
            body = {"unhideRows": {"force": force, "intervals": [{"start": start_index}]}}

        logger.info("Function get_unhide_range_body ended")
        return body

    @staticmethod
    def get_merge_ranges_body(ranges: list, merge_type: str = '', force=True) -> dict:
        """
        Gets merge ranges body.

        :param ranges: list of merge ranges.
        :param merge_type: type of merge (HORIZONTAL or VERTICAL).
        :param force(optional): force(True/False).

        :return: merge ranges body.
        """
        body = {"force": force, "mergeType": merge_type, "ranges": ranges}
        return body

    @staticmethod
    def json_to_string(data):
        """
        Converts string to json.

        :param data: string data.

        :return: converted JSON data.
        """
        return json.dumps(data)
