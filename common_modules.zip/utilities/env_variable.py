import os


class EnvVariables:

    @staticmethod
    def get_study_number_s3() -> str:
        return os.getenv('STUDY_NUMBER', default='')

    @staticmethod
    def get_analysis_type_s3() -> str:
        return os.getenv('ANALYSIS_TYPE', default='')

    @staticmethod
    def get_product_name_s3() -> str:
        return os.getenv('PRODUCT_NAME', default='')

    @staticmethod
    def get_content_plan_id_s3() -> str:
        return os.getenv('CONTENT_PLAN_ID', default='')

    @staticmethod
    def get_document_id() -> str:
        return os.getenv('DOCUMENT_ID', default='')

    @staticmethod
    def get_bucket_name_s3() -> str:
        return os.getenv('BUCKET_NAME', default='')

    @staticmethod
    def get_file_path_s3() -> str:
        return os.getenv('FILE_PATH', default='')

    @staticmethod
    def get_input_sheet_id() -> str:
        return os.getenv('INPUT_FORM_ID', default='')

    @staticmethod
    def get_csr_id() -> str:
        return os.getenv('CSR_ID', default='')

    @staticmethod
    def get_task_no() -> str:
        return os.getenv('TASK_NO', default='')

    @staticmethod
    def get_product_family_s3() -> str:
        return os.getenv('PRODUCT_FAMILY', default='')

    @staticmethod
    def get_output_document_type_s3() -> str:
        return os.getenv('OUTPUT_DOCUMENT_TYPE', default='')

    @staticmethod
    def get_indication_s3() -> str:
        return os.getenv('INDICATION', default='')

    @staticmethod
    def get_co_file_name() -> str:
        return os.getenv('CO_FILE_NAME', default='')
