from enum import Enum


class WorkivaApiURLs(Enum):
    AUTH_URL = "https://api.app.wdesk.com/iam/v1/oauth2/token"
    SS_API_URL = "https://api.app.wdesk.com/platform/v1/spreadsheets/"
    WDATA_API_URL = "https://h.app.wdesk.com/s/wdata/prep/"
    CONN_API_URL = "https://h.app.wdesk.com/s/wdata/prep/api/v1/connections"
    SS_SS_API_URL = "https://api.app.wdesk.com/spreadsheets/v1/spreadsheets/"
    DOC_API_URL = "https://api.app.wdesk.com/platform/v1/documents/"
    FILE_API_URL = "https://api.app.wdesk.com/platform/v1/files/"
    SCRIPT_API_URL = "https://api.app.wdesk.com/prototype/platform/scripts/"
    PROTOTYPE_PLATFORM_URL = "https://api.app.wdesk.com/prototype/platform/"
    TASK_API_URL = "https://api.app.wdesk.com/platform/v1/tasks"
    CHAIN_API_URL = "https://h.app.wdesk.com/s/wdata/oc/api/v1/execute/environment/"
    WDATA_QUERY_RESULT_API = "https://h.app.wdesk.com/s/wdata/prep/api/v1/queryresult/"
    AUTOMATIONS_URL = "https://h.app.wdesk.com/s/automations/api/v1/automations"
    ADMIN_API_URL = "https://api.app.wdesk.com/prototype/admin/organizations/"
    USERS_API_URL = "https://api.app.wdesk.com/platform/v1/users"
    PERMISSION_API_URL = "https://api.app.wdesk.com/prototype/platform/permissions"
    DOC_PERMISSION_API_URL = "https://api.app.wdesk.com/prototype/platform/documents/"
    SS_PERMISSIONS_API_URL = "https://api.app.wdesk.com/prototype/platform/spreadsheets/"
    DOC_IMPORT_URL = 'https://app.wdesk.com/s/cerberus/api/v0/import/document'
