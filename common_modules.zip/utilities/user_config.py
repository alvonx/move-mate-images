from utilities.config import Config


class UserConfig:

    def __init__(self) -> None:
        self._config = Config()

    def get_client_id(self) -> str:
        return self._config.client_id

    def get_client_secret(self) -> str:
        return self._config.client_secret
