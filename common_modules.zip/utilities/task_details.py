from enum import Enum


class TaskDetails:

    class TaskTitle(Enum):
        TASK_1 = "Input Parameters to Start Authoring"
        TASK_2 = "Review Pre-authored"
        TASK_3 = "Review Data and Confirm Outline for"
        TASK_4 = "Complete Section-TFL mapping for"
        TASK_5 = "Modify In-text tables for "
        TASK_6 = "doc_name is ready for export"

    class TaskDescription(Enum):
        TASK_1 = "\n\nYou have been assigned a new CSR for authoring. Please click on 'Go to Task' to complete the following:\n\n1. Select Product family, Study / Branch Number, Data cut-off date and Content Plan Details\n2. Check Status in GenCTD to confirm CSR outline is available \n3. Click on automation panel (⚡) and run 'A1. Prepare CSR for Authoring'\n\nOnce you complete the above steps, we will prepare the CSR template for your review and it will take around 5-10 minutes. Sit back and relax. We will send you an email with the next steps once done."
        TASK_2 = "template is ready for authoring. You can now click on 'Go to task' and review the template. \n\nWhile you review the template, we are also getting the TFL data for your review and the process will take around 15-20 minutes. We will send you an email with the next steps once the data is available."
        TASK_3 = "\n\n The TFL data is now available for review. Please click on 'Go to Task' to complete the folowing: \n\n 1. Select the 'Important to Describe TFLs' and 'Important to Include In-Text TFLs' in the Section-TFL list \n2. Go to CSR and review the section outline in case you want to make any changes based on data (add/remove subsections).\n3. While adding new section add '_new' at the end of the section name.\n4. Update section heading for '8.4.1' and '8.4.2' sections.\n5. Review and update sections '8.9' and '8.10' as per the instructions\n6. Click on automation panel (⚡) and run: 'A2. Confirm section outline' \n\nOnce you complete the above steps, we will start processing the section outline and it will take around 5 minutes. We will send you an email with the next steps once done."
        TASK_4 = "\n\nThe TFLs are now ready to be mapped to Sections. Please click on 'Go to Task' and complete the following:\n\n1. Select the TFLs from the dropdowns in front of each section/subsection in the input form sheets for section 9, 10 and 12.\n2. Once done, click on automation panel (⚡) and run: 'A3. Prepare Tables for modification' \n\nOnce you complete the above steps, we will process the In-text tables for modification. The process can take around 30 minutes. Sit back and relax. We will send you an email with the next steps once done."
        TASK_5 = "\n\nThe tables are now ready to modify. You can click on 'Go to Task' and complete the following:\n\n1. Make changes to the tables to be included in the CSR as required. \n2. Once all the tables are modified as required, Click on automation panel (⚡) and run: 'A4: Generate Content'\n\nOnce you complete the above steps, we will share the information with GenCTD for data generation and you will receive a notification from GenCTD once the generated data is available for review."
        TASK_6 = "Congratulations! The CSR Draft 1 is now ready to export. You can now click on 'Go to Task' and perform the following action to export the document: \n\n1. Cick on 'File' in the ribbon options \n2. Click on 'Save as' and select the .DOCX format. In the pop-up window, select advanced and select embed fonts (everything else will remain as is) \n3. Click on Export \n\nThe document will download in a few seconds.\n\n You prepared a draft CSR in just total_time_taken and saved over 80% of your manual authoring effort!"
