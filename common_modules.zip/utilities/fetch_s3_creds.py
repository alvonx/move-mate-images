from api_calls.ss_api import SSApi
from api_calls.file_api import FileApi
from utilities.utility import Utilities
from constants import STAGING_AREA_FOLDER, CONFIG_SHEET_NAME, S3_CONFIG_SS_NAME


class S3Creds:

    def get_config_file(self, input_spreadsheet_id):
        """
        Fetch the id of the config file.
                
        Args:
            input_spreadsheet_id : id of the input sheet
            
        Returns:
            config_ss_id: config file id.
        """
        files_api_obj = FileApi()
        config_folder_id = ''
        config_ss_id = ''
        container_id = files_api_obj.get_parent_id(input_spreadsheet_id)
        files_in_the_container = files_api_obj.get_list_of_files(container_id)

        for file in files_in_the_container:
            if file['kind'] == 'Folder' and file['name'] == STAGING_AREA_FOLDER:
                config_folder_id = file['id']
                break
        files_in_staging_area = files_api_obj.get_list_of_files(config_folder_id)
        for doc in files_in_staging_area:
            if doc['kind'] == 'Spreadsheet' and S3_CONFIG_SS_NAME in doc['name']:
                config_ss_id = doc['id']
                break
        return config_ss_id

    def get_aws_credentials(self, input_spreadsheet_id):
        """
        Get AWS creds from the config sheet.
                
        Args:
            input_spreadsheet_id : id of the spreadsheet
            
        Returns:
            Sets the static variable of AWS() class.
        """
        ss_api_obj = SSApi()
        config_sheet_id = ''
        AWS_CREDS = {'AWS_ACCESS_KEY_ID': '', 'AWS_SECRET_ACCESS_KEY': '', 'BUCKET_NAME': ''}

        #fetch config spreadsheet id
        config_ss_id = self.get_config_file(input_spreadsheet_id)

        #fetch sheets in the config spreadsheet
        sheets_in_config_file = ss_api_obj.get_sheets(config_ss_id)['data']

        #fetch sheet id of the sheet containing the creds
        for sheet in sheets_in_config_file:
            if sheet['name'] == CONFIG_SHEET_NAME:
                config_sheet_id = sheet['id']
                break

        raw_data = ss_api_obj.get_raw_data(config_ss_id, config_sheet_id)['data'][0]['values']
        s3_creds_df = Utilities.get_dataframe(data=raw_data[1:], columns=raw_data[0])

        #set the static variables of AWS() class
        for _, row in s3_creds_df.iterrows():
            AWS_CREDS[row['Key Name']] = row['Value']

        return AWS_CREDS
