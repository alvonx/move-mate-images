import time
from api_calls.file_api import FileApi
from api_calls.doc_api import DocApi
from utilities.utility import Utilities

from base.base_logger import get_base_logger

logger = get_base_logger()

class CheckAvailability:

    def __init__(self):
        self._doc_api_obj: DocApi = DocApi()
        self._file_api_obj: FileApi = FileApi()
        self._utilities_obj: Utilities = Utilities()

    def check_file_availability(self, file_name: str, kind: str) -> bool:
        """
        Checks if the file is available in the entire Workspace.

        :params file_name: File name
        :params kind: File kind
        :return: True or False based on the availability of file.
        """
        delay = 5
        max_retries = 15
        logger.info(f"Checking if '{file_name}' {kind} is available in Workiva...")
        for attempt in range(max_retries):
            res = self._file_api_obj.get_list_of_files(name=file_name, kind=kind)
            file_id = self._utilities_obj.get_file_id(file_list=res, file_name=file_name)

            if file_id:
                logger.info("File is available!!!")
                return True
            else:
                time.sleep(delay)

        return False
    
    def check_section_availability(self, document_id: str, section_name: str) -> bool:
        """
        Checks if the section is available in the document.

        :params document_id: Document ID.
        :params section_name: Section name.
        :return: True or False based on the availability of section in the document.
        """
        delay = 5
        max_retries = 15
        logger.info(f"Checking if '{section_name}' section is available in the document...")
        for attempt in range(max_retries):
            res = self._doc_api_obj.get_list_of_sections(document_id)
            section_id = self._utilities_obj.get_section_attributes(res, section_name, 'id')

            if section_id != 'ID NOT FOUND':
                logger.info("Section is available!!!")
                return True
            else:
                time.sleep(delay)

        return False
        