class Config:

    def __init__(self) -> None:
        # self.client_id: str = "e3ca9421-f7f6-4b1d-894c-866275b87f97"
        # self.client_secret: str = "wk_secret:oa2c:6AoDMmNxSlIEXWAh36iA"
        self.client_id: str = "1d77c67f-357a-4a6f-9be8-177fd5835281"
        self.client_secret: str = "wk_secret:oa2c:nkM8kMLpfcUFr4nsBh0v"
