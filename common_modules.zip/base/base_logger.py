import logging


def get_base_logger() -> logging.Logger:
    logging.basicConfig(format='%(name)s | %(levelname)s | %(asctime)s - %(message)s')

    logger = logging.getLogger("Amgen-Clinical")
    logger.setLevel(logging.INFO)

    return logger
