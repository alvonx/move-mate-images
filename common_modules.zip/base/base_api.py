import json
import logging
import time
import requests
from requests import Response
from api_calls.api_auth import TokenManager
from base.base_logger import get_base_logger

logger = get_base_logger()


class BaseApi:

    def __init__(self):
        self._token_manager: TokenManager = TokenManager()
        self.headers = {'Accept': 'application/json', 'Authorization': self._token_manager.get_auth_token()}

    def get_request(self, url: str, params=None, retry: int = 1) -> Response:
        '''Base GET request method for all GET Api calls
            
            Returns: 
                Api Response
        '''
        try:
            response: requests.Response = requests.get(url, params=params, headers=self.headers)
            response.raise_for_status()
        except requests.exceptions.HTTPError as exception:
            if response.status_code == 401 and retry < 5:    # Unauthorized - token might be expired

                logger.info("Token expired, regenerating token..." + str(exception))
                time.sleep(2)

                self._token_manager.regenerate_auth_token()
                self.headers['Authorization'] = self._token_manager.get_auth_token()

                response = self.get_request(url, params, retry + 1)
            elif (response.status_code in [400, 429, 500]) and retry < 5:
                time.sleep(2)
                response = self.get_request(url, params, retry + 1)
            else:
                raise exception

        return response

    def post_request(self, url: str, body: dict, retry: int = 1, file=None) -> Response:
        '''Base POST request method for all POST Api calls
            
            Returns: 
                Api Response
        '''
        try:
            if body == {}:
                response = requests.post(url, headers=self.headers, files=file)
            else:
                response = requests.post(url, headers=self.headers, data=json.dumps(body), files=file)

            if 'retry-after' in response.headers:
                time.sleep(int(response.headers['retry-after']))

            response.raise_for_status()
        except requests.exceptions.HTTPError as exception:
            if response.status_code == 401 and retry < 5:    # Unauthorized - token might be expired
                logger.info("Token expired, regenerating token..." + str(exception))
                time.sleep(2)

                self._token_manager.regenerate_auth_token()
                self.headers['Authorization'] = self._token_manager.get_auth_token()

                response = self.post_request(url, body, retry + 1, file=file)
            elif (response.status_code in [400, 429, 500]) and retry < 5:
                time.sleep(2)
                response = self.post_request(url, body, retry + 1, file=file)
            else:
                raise exception

        return response

    def put_request(self, url: str, body: dict, retry: int = 1) -> Response:
        '''Base PUT request method for all PUT Api calls
            
            Returns: 
                Api Response
        '''
        try:
            response = requests.put(url, headers=self.headers, data=json.dumps(body))

            if 'retry-after' in response.headers:
                time.sleep(int(response.headers['retry-after']))

            response.raise_for_status()
        except requests.exceptions.HTTPError as exception:
            if response.status_code == 401 and retry < 5:    # Unauthorized - token might be expired
                logger.info("Token expired, regenerating token..." + str(exception))
                time.sleep(2)

                self._token_manager.regenerate_auth_token()
                self.headers['Authorization'] = self._token_manager.get_auth_token()

                response = self.put_request(url, body, retry + 1)
            elif (response.status_code in [400, 429, 500]) and retry < 5:
                time.sleep(2)
                response = self.put_request(url, body, retry + 1)
            else:
                raise exception

        return response
    
    def patch_request(self, url: str, body: dict, retry: int = 1) -> Response:
        '''Base PATCH request method for all PATCH Api calls
            
            Returns: 
                Api Response
        '''
        try:
            response = requests.patch(url, headers=self.headers, data=json.dumps(body))

            if 'retry-after' in response.headers:
                time.sleep(int(response.headers['retry-after']))

            response.raise_for_status()
        except requests.exceptions.HTTPError as exception:
            if response.status_code == 401 and retry < 5:    # Unauthorized - token might be expired
                logger.info("Token expired, regenerating token..." + str(exception))
                time.sleep(2)

                self._token_manager.regenerate_auth_token()
                self.headers['Authorization'] = self._token_manager.get_auth_token()

                response = self.patch_request(url, body, retry + 1)
            elif (response.status_code in [400, 429, 500]) and retry < 5:
                time.sleep(2)
                response = self.patch_request(url, body, retry + 1)
            else:
                raise exception

        return response

    def delete_request(self, url: str, retry: int = 1):
        '''Base DELETE request method for all DELETE Api calls
            
            Returns: 
                Api Response
        '''
        try:
            response = requests.delete(url, headers=self.headers)

            if 'retry-after' in response.headers:
                time.sleep(int(response.headers['retry-after']))

            response.raise_for_status()
        except requests.exceptions.HTTPError as exception:
            if response.status_code == 401 and retry < 5:    # Unauthorized - token might be expired
                logger.info("Token expired, regenerating token..." + str(exception))
                time.sleep(2)

                self._token_manager.regenerate_auth_token()
                self.headers['Authorization'] = self._token_manager.get_auth_token()

                response = self.delete_request(url, retry + 1)
            elif (response.status_code in [400, 429, 500]) and retry < 5:
                time.sleep(2)
                response = self.delete_request(url, retry + 1)
            else:
                raise exception

        return response
